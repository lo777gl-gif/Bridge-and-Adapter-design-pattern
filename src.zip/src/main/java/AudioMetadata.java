public record AudioMetadata(int channels, int sampleRate, int bitDepth) { }
